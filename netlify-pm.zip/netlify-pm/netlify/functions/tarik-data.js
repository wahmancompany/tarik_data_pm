// Netlify Function: tarik-data
// Token diambil dari Environment Variable MENTOR_AUTH_TOKEN (rahasia, hanya admin via dashboard Netlify)
// User cukup memanggil endpoint ini -> dapat file Excel berwarna.

const XLSX = require('xlsx-js-style');

const BALI_NAMES = ["Nancy Riyani Ridwan","Mohamad Iqbal Septiana","Muhammad Zainur Rokhim","Komang Sumerta","Gede Susila Dharma","Dikanio Dwi Septi","Ida Bagus Gede Darma Putra","I Kadek Jepri","Sartika","I Gede Budhi Sanjaya","Vita Martha Diana","Zulkarnain","Rahmat Fitriadi","Komang Merta","Ngakan Nyoman Darmayasa","Raizzal Ahmad Weikiansyah","Made Mahendra Putra","I Made Edy Tiro Sugiarta","Ni Luh Putu Lidya Sarita Dewi","Laila Muluda Yani","Aldi Eka Putra","Alfatah Suparno","Fakhri Hidayat","Sesilia Febriyanti Dila Alli","Muhammad Maimum Alfan","I Dewa Made Putra Juniarta","Fikri Rahmadi Indrawan","I Nyoman Wandi Dwiparwata","Imamah Syamsiah","Ni Putu Eka Wijayati","Al Asaril Fatoni","Mochamad Chaisar Arif Rozak","Adriansyah Putra Widitama","Erwin Raniar","Ni Kadek Widya Sari","Ryan Hidayatullah","Ade Ravi Putra Arya"];
const NUSRA_NAMES = ["Hardyhansyah Abdul Adjid Mekeseer","Nurhasin","Januarius Natonis","Yordant Bonbalan","Muhammad Noor Taufik","Junaidy Bastian Dama","Videlis Bala","Irmansyah","Julamdo Harter Katta","Selamun","Imam Mahdin","Marthen Jakobus Ludji","Ulul Arham","Zidan Maulana","Adi Putra Imanuel Lede","Loudric Junino Pratama Lapenangga","Ferdisitas Dam Fayon","Iwan Suryadi Saputra","Nazwir Kahfi","Aleander Servani Onggo","BOT BALI DISMANTLE"];

const PAGE_SIZE = 1500;

// Rentang tanggal = bulan berjalan otomatis (sehingga tetap relevan tiap bulan)
function monthRange() {
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = now.getUTCMonth(); // 0-based
  const pad = (n) => String(n).padStart(2, '0');
  const start = `${y}-${pad(m + 1)}-01`;
  const lastDay = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  const end = `${y}-${pad(m + 1)}-${pad(lastDay)}`;
  return { start, end };
}

function buildUrl(page) {
  const { start, end } = monthRange();
  const base = 'https://memo-api.pcsindonesia.com/v2/master/ticket';
  const params = {
    page: String(page),
    page_size: String(PAGE_SIZE),
    filter: '',
    order: 'created_at:-1',
    param: 'sp_id:8',
    start_date: start,
    end_date: end,
    date_field: 'created_at',
    leader_id: '792',
    is_historical: '0',
    preload: 'User,InstallTypeTicket'
  };
  const u = new URL(base);
  Object.entries(params).forEach(([k, v]) => u.searchParams.append(k, v));
  return u.toString();
}

async function fetchAll(token) {
  const headers = { Authorization: token };

  // Halaman 1 untuk tahu jumlah total
  const first = await fetch(buildUrl(1), { headers });
  if (first.status === 401 || first.status === 403) {
    throw new Error('Token tidak valid atau sudah kedaluwarsa. Minta admin perbarui token.');
  }
  if (!first.ok) throw new Error('Gagal mengambil data (status ' + first.status + ').');

  const firstData = await first.json();
  const total = firstData.count || 0;
  let all = firstData.data || [];

  const pages = Math.ceil(total / PAGE_SIZE);
  if (pages > 1) {
    // Ambil sisa halaman secara paralel supaya cepat (hemat waktu function)
    const reqs = [];
    for (let p = 2; p <= pages; p++) {
      reqs.push(fetch(buildUrl(p), { headers }).then((r) => (r.ok ? r.json() : { data: [] })));
    }
    const results = await Promise.all(reqs);
    for (const d of results) {
      if (d && d.data) all = all.concat(d.data);
    }
  }
  return all;
}

function filterPM(rows) {
  const pmRows = rows.filter(
    (r) => r.install_type_ticket && r.install_type_ticket.name === 'Preventive Maintenance (PM)'
  );

  const seen = new Set();
  const summary = {};
  for (const r of pmRows) {
    const key = `${r.subtiket_id}|${r.tid}`;
    if (seen.has(key)) continue;
    seen.add(key);

    const tek = (r.User && r.User.name) || 'Unknown';
    const done = r.done_date && String(r.done_date).trim();
    if (!summary[tek]) summary[tek] = { onProgress: 0, pending: 0, done: 0, doneToday: 0, total: 0 };
    summary[tek].onProgress += done ? 0 : 1;
    summary[tek].done += done ? 1 : 0;
    summary[tek].total += 1;
  }

  const aggregate = (names) =>
    Object.entries(summary)
      .filter(([tek]) => names.includes(tek))
      .map(([tek, c]) => ({
        teknisi: tek,
        onProgress: c.onProgress,
        pending: c.pending,
        done: c.done,
        doneToday: c.doneToday,
        total: c.total,
        pctDone: c.total > 0 ? Math.round((c.done / c.total) * 100) : 0
      }))
      .sort((a, b) => b.pctDone - a.pctDone);

  const bali = aggregate(BALI_NAMES).map((r, i) => ({ ...r, no: i + 1 }));
  const nusra = aggregate(NUSRA_NAMES).map((r, i) => ({ ...r, no: i + 1 }));
  return { bali, nusra };
}

function buildExcel(baliData, nusraData) {
  const getColor = (pct) => {
    if (pct === 100) return 'FFFFFF';
    if (pct >= 75) return '92D050';
    if (pct >= 35) return 'FFFF00';
    return 'FF0000';
  };
  const BRD = { style: 'thin', color: { rgb: 'BFBFBF' } };
  const border = { top: BRD, bottom: BRD, left: BRD, right: BRD };
  const titleStyle = { font: { bold: true, sz: 14, color: { rgb: '1F3864' }, name: 'Arial' } };
  const headerStyle = {
    fill: { patternType: 'solid', fgColor: { rgb: '4472C4' } },
    font: { bold: true, sz: 10, color: { rgb: 'FFFFFF' }, name: 'Arial' },
    alignment: { horizontal: 'center', vertical: 'center', wrapText: true },
    border
  };
  const dataStyle = (color, col) => ({
    fill: { patternType: 'solid', fgColor: { rgb: color } },
    font: { sz: 10, name: 'Arial' },
    alignment: { horizontal: col === 1 ? 'left' : 'center', vertical: 'center' },
    border
  });
  const totalStyle = (color, col) => ({
    fill: { patternType: 'solid', fgColor: { rgb: color } },
    font: { bold: true, sz: 10, name: 'Arial' },
    alignment: { horizontal: col === 1 ? 'left' : 'center', vertical: 'center' },
    border
  });

  const aoa = [];
  const ops = [];
  const rowHeights = [];
  const HEADERS = ['No', 'Nama MERi', 'PM On Progress', 'PM Pending', 'PM Done Total', 'PM Done Hari Ini', 'Total PM', '% Done'];

  function pushSection(title, data, areaName) {
    let r = aoa.length;
    aoa.push([title]); ops.push({ r, c: 0, s: titleStyle }); rowHeights[r] = 22;
    aoa.push([]);
    r = aoa.length;
    aoa.push(HEADERS.slice()); HEADERS.forEach((_, c) => ops.push({ r, c, s: headerStyle })); rowHeights[r] = 30;
    for (const it of data) {
      r = aoa.length;
      const color = getColor(it.pctDone);
      aoa.push([it.no, it.teknisi, it.onProgress, it.pending, it.done, it.doneToday, it.total, it.pctDone + '%']);
      for (let c = 0; c < 8; c++) ops.push({ r, c, s: dataStyle(color, c) });
    }
    const t = { onProgress: 0, pending: 0, done: 0, doneToday: 0, total: 0 };
    data.forEach((d) => { t.onProgress += d.onProgress; t.pending += d.pending; t.done += d.done; t.doneToday += d.doneToday; t.total += d.total; });
    const pct = t.total > 0 ? Math.round((t.done / t.total) * 100) : 0;
    r = aoa.length;
    aoa.push(['', 'TOTAL ' + areaName, t.onProgress, t.pending, t.done, t.doneToday, t.total, pct + '%']);
    for (let c = 0; c < 8; c++) ops.push({ r, c, s: totalStyle('92D050', c) });
    aoa.push([]);
    return t;
  }

  const bt = pushSection('Area Bali - Laporan PM', baliData, 'BALI');
  const nt = pushSection('Area NUSRA - Laporan PM', nusraData, 'NUSRA');

  const g = {
    onProgress: bt.onProgress + nt.onProgress,
    pending: bt.pending + nt.pending,
    done: bt.done + nt.done,
    doneToday: bt.doneToday + nt.doneToday,
    total: bt.total + nt.total
  };
  const gpct = g.total > 0 ? Math.round((g.done / g.total) * 100) : 0;
  let r = aoa.length;
  aoa.push(['', 'TOTAL KESELURUHAN', g.onProgress, g.pending, g.done, g.doneToday, g.total, gpct + '%']);
  for (let c = 0; c < 8; c++) ops.push({ r, c, s: totalStyle('A9D08E', c) });

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ops.forEach(({ r, c, s }) => {
    const addr = XLSX.utils.encode_cell({ r, c });
    if (!ws[addr]) ws[addr] = { t: 's', v: '' };
    ws[addr].s = s;
  });
  ws['!cols'] = [{ wch: 6 }, { wch: 34 }, { wch: 16 }, { wch: 12 }, { wch: 14 }, { wch: 16 }, { wch: 11 }, { wch: 10 }];
  ws['!rows'] = rowHeights.map((h) => (h ? { hpt: h } : {}));

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Laporan PM');
  return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
}

exports.handler = async function () {
  const token = process.env.MENTOR_AUTH_TOKEN;
  if (!token) {
    return { statusCode: 500, body: 'MENTOR_AUTH_TOKEN belum diatur. Admin perlu menambahkannya di Environment Variables Netlify.' };
  }
  try {
    const rows = await fetchAll(token);
    const { bali, nusra } = filterPM(rows);
    const buf = buildExcel(bali, nusra);
    const today = new Date().toISOString().split('T')[0];
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="Laporan_PM_${today}.xlsx"`
      },
      body: buf.toString('base64'),
      isBase64Encoded: true
    };
  } catch (e) {
    return { statusCode: 500, body: 'Error: ' + e.message };
  }
};
