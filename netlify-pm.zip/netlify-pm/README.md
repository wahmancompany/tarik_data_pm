# Tarik Data PM — Versi Web (Netlify)

Aplikasi web sederhana: user cukup klik tombol **"Tarik Data"** untuk mengunduh laporan PM (Excel berwarna). Token MENTOR disimpan **rahasia** dan hanya bisa diatur oleh admin.

---

## Cara Kerja (Singkat)

- **Halaman web (index.html)** → hanya berisi tombol. Token TIDAK ada di sini.
- **Function (netlify/functions/tarik-data.js)** → berjalan di server Netlify, memakai token rahasia, menarik data dari MENTOR, lalu membuat Excel.
- **Token** → disimpan di **Environment Variable** Netlify bernama `MENTOR_AUTH_TOKEN`. Hanya admin (pemilik akun Netlify) yang bisa lihat/ubah lewat dashboard.

```
netlify-pm/
├── index.html                      (halaman user: tombol saja)
├── netlify.toml                    (konfigurasi Netlify)
├── package.json                    (daftar library)
└── netlify/
    └── functions/
        └── tarik-data.js           (kode server + token rahasia)
```

---

## Cara Deploy ke Netlify (Tanpa Command Line)

### Langkah 1 — Siapkan kode di GitHub
1. Buat akun di https://github.com (gratis) bila belum punya.
2. Klik **New repository** → beri nama (misal `tarik-data-pm`) → **Create**.
3. Di halaman repo, klik **Add file → Upload files**.
4. Upload SEMUA isi folder `netlify-pm` (termasuk folder `netlify`). Cara mudah: seret-lepas (drag & drop) seluruh file & folder.
5. Klik **Commit changes**.

### Langkah 2 — Hubungkan ke Netlify
1. Buat akun di https://netlify.com (gratis), login pakai GitHub.
2. Klik **Add new site → Import an existing project → GitHub**.
3. Pilih repo `tarik-data-pm` tadi.
4. Biarkan pengaturan default (Netlify membaca `netlify.toml` otomatis). Klik **Deploy**.

### Langkah 3 — Masukkan Token (PENTING)
1. Setelah situs jadi, buka **Site configuration → Environment variables**.
2. Klik **Add a variable**:
   - **Key:** `MENTOR_AUTH_TOKEN`
   - **Value:** token MENTOR Anda (lengkap dengan kata `Bearer ` di depannya)
3. **Save**.
4. Buka **Deploys → Trigger deploy → Deploy site** (agar token terbaca).

Selesai! Buka alamat situs Anda (misal `https://tarik-data-pm.netlify.app`) → klik **Tarik Data**.

### Langkah 4 (Opsional) — Pasang Domain Sendiri
- **Domain settings → Add a domain** → ikuti petunjuk untuk arahkan domain Anda ke Netlify.

---

## Cara Memperbarui Token (Saat Expired)
Kalau muncul pesan *"Token tidak valid / kedaluwarsa"*:
1. Ambil token MENTOR yang baru.
2. Buka Netlify → **Environment variables** → edit `MENTOR_AUTH_TOKEN` → ganti dengan token baru → **Save**.
3. **Trigger deploy** sekali lagi.

Hanya admin yang bisa melakukan ini. User lain tidak perlu tahu token-nya.

---

## Catatan Teknis
- Rentang tanggal otomatis mengikuti **bulan berjalan**. Jadi tiap bulan baru, laporan ikut menyesuaikan tanpa perlu edit kode.
- Function dibatasi **±10 detik** di paket gratis Netlify. Pengambilan halaman sudah dibuat **paralel** agar cepat. Jika data sangat besar dan sering timeout, paket berbayar Netlify menaikkan batas waktu ini.
- Hanya admin yang punya akses ke dashboard Netlify yang dapat melihat/mengubah token.

---

## (Opsional) Membatasi Siapa yang Boleh Membuka Halaman
Secara default, siapa pun yang tahu alamat situs bisa menekan tombol. Bila ingin membatasi:
- Netlify menyediakan **Password protection** (paket berbayar) di **Site configuration → Access control**, atau
- Bisa ditambahkan halaman login sederhana. Beri tahu bila Anda perlu ini.
